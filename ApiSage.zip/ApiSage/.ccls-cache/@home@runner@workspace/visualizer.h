#ifndef VISUALIZER_H
#define VISUALIZER_H

#include <string>
#include <vector>
#include <chrono>

struct VisualizationData {
    int total_requests;
    int successful_requests;
    int failed_requests;
    double avg_response_time;
    double throughput;
    std::vector<double> recent_response_times;
};

class Visualizer {
private:
    static const int GRAPH_WIDTH = 60;
    static const int GRAPH_HEIGHT = 10;
    
    std::string create_bar_graph(const std::string& label, int value, int max_value, int width);
    std::string create_line_graph(const std::vector<double>& data, const std::string& title);
    std::string create_progress_bar(int current, int total, int width);

public:
    Visualizer();
    
    void clear_screen();
    void display_live_stats(const VisualizationData& data, int total_target);
    void display_summary(const VisualizationData& data, double min_latency, double max_latency);
    void display_header(const std::string& title);
};

#endif
