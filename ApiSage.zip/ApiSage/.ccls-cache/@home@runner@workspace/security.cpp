#include "security.h"
#include <iostream>
#include <regex>
#include <algorithm>
#include <cctype>

SecurityChecker::SecurityChecker() {}

bool SecurityChecker::is_valid_url(const std::string& url) {
    std::regex url_pattern(R"(^https?://[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,}(/.*)?$)");
    return std::regex_match(url, url_pattern);
}

std::string SecurityChecker::extract_hostname(const std::string& url) {
    std::regex hostname_pattern(R"(https?://([a-zA-Z0-9\-\.]+))");
    std::smatch matches;
    
    if (std::regex_search(url, matches, hostname_pattern) && matches.size() > 1) {
        return matches[1].str();
    }
    
    return "";
}

bool SecurityChecker::is_trusted_domain(const std::string& hostname) {
    std::vector<std::string> trusted_domains = {
        "localhost",
        "127.0.0.1",
        "jsonplaceholder.typicode.com",
        "httpbin.org",
        "postman-echo.com",
        "reqres.in",
        "api.github.com",
        "google.com",
        "example.com"
    };
    
    for (const auto& domain : trusted_domains) {
        if (hostname.find(domain) != std::string::npos) {
            return true;
        }
    }
    
    return false;
}

bool SecurityChecker::is_safe_port(int port) {
    return (port == 80 || port == 443 || port == 8080 || port == 3000 || port == 5000);
}

bool SecurityChecker::check_ssl_certificate(const std::string& url) {
    return url.find("https://") == 0;
}

SecurityCheckResult SecurityChecker::validate_url(const std::string& url) {
    SecurityCheckResult result;
    result.is_safe = true;
    
    if (!is_valid_url(url)) {
        result.is_safe = false;
        result.errors.push_back("Invalid URL format");
        return result;
    }
    
    std::string hostname = extract_hostname(url);
    
    if (hostname.empty()) {
        result.is_safe = false;
        result.errors.push_back("Could not extract hostname from URL");
        return result;
    }
    
    if (!is_trusted_domain(hostname)) {
        result.warnings.push_back("Domain '" + hostname + "' is not in the trusted list");
        result.warnings.push_back("Please verify this is a legitimate endpoint");
    }
    
    if (url.find("https://") != 0) {
        result.warnings.push_back("URL does not use HTTPS - data will be transmitted insecurely");
    }
    
    if (url.find(":") != std::string::npos && url.find("://") != std::string::npos) {
        size_t port_pos = url.find(":", url.find("://") + 3);
        if (port_pos != std::string::npos) {
            result.warnings.push_back("Custom port detected in URL");
        }
    }
    
    return result;
}

SecurityCheckResult SecurityChecker::validate_request_config(const std::string& url, 
                                                             const std::string& method, 
                                                             const std::string& body) {
    SecurityCheckResult result = validate_url(url);
    
    if (method != "GET" && method != "POST" && method != "PUT" && method != "DELETE") {
        result.warnings.push_back("Unusual HTTP method: " + method);
    }
    
    if (!body.empty() && body.length() > 1000000) {
        result.warnings.push_back("Request body is very large (>1MB)");
    }
    
    return result;
}

bool SecurityChecker::is_suspicious_response(long status_code, double response_time_ms) {
    if (status_code == 429) {
        return true;
    }
    
    if (status_code >= 500 && status_code < 600) {
        return true;
    }
    
    if (response_time_ms > 10000) {
        return true;
    }
    
    return false;
}

std::string SecurityChecker::sanitize_input(const std::string& input) {
    std::string sanitized = input;
    
    sanitized.erase(std::remove(sanitized.begin(), sanitized.end(), '\0'), sanitized.end());
    
    return sanitized;
}

bool SecurityChecker::prompt_user_confirmation(const std::string& url) {
    std::cout << "\n⚠️  WARNING: You are about to send requests to: " << url << "\n";
    std::cout << "This domain is not in the trusted list.\n";
    std::cout << "Do you want to proceed? (yes/no): ";
    
    std::string response;
    std::getline(std::cin, response);
    
    std::transform(response.begin(), response.end(), response.begin(), ::tolower);
    
    return (response == "yes" || response == "y");
}
