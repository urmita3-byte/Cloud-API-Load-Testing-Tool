#include "visualizer.h"
#include <iostream>
#include <iomanip>
#include <sstream>
#include <algorithm>
#include <cmath>

Visualizer::Visualizer() {}

void Visualizer::clear_screen() {
    std::cout << "\033[2J\033[1;1H";
}

std::string Visualizer::create_bar_graph(const std::string& label, int value, int max_value, int width) {
    std::stringstream ss;
    ss << std::setw(20) << std::left << label << " [";
    
    int filled = 0;
    if (max_value > 0) {
        filled = (value * width) / max_value;
    }
    
    for (int i = 0; i < width; ++i) {
        if (i < filled) {
            ss << "█";
        } else {
            ss << "░";
        }
    }
    
    ss << "] " << value;
    if (max_value > 0) {
        ss << " (" << std::fixed << std::setprecision(1) << (100.0 * value / max_value) << "%)";
    }
    
    return ss.str();
}

std::string Visualizer::create_line_graph(const std::vector<double>& data, const std::string& title) {
    if (data.empty()) {
        return "";
    }
    
    std::stringstream ss;
    ss << "\n" << title << "\n";
    
    double max_val = *std::max_element(data.begin(), data.end());
    double min_val = *std::min_element(data.begin(), data.end());
    
    if (max_val == min_val) {
        max_val = min_val + 1;
    }
    
    for (int row = GRAPH_HEIGHT - 1; row >= 0; --row) {
        double threshold = min_val + (max_val - min_val) * row / (GRAPH_HEIGHT - 1);
        ss << std::setw(6) << std::fixed << std::setprecision(0) << threshold << " │";
        
        int step = std::max(1, static_cast<int>(data.size()) / GRAPH_WIDTH);
        for (size_t i = 0; i < data.size(); i += step) {
            if (data[i] >= threshold) {
                ss << "█";
            } else {
                ss << " ";
            }
        }
        ss << "\n";
    }
    
    ss << "       └";
    for (int i = 0; i < GRAPH_WIDTH; ++i) {
        ss << "─";
    }
    ss << "\n";
    
    return ss.str();
}

std::string Visualizer::create_progress_bar(int current, int total, int width) {
    std::stringstream ss;
    
    int filled = 0;
    if (total > 0) {
        filled = (current * width) / total;
    }
    
    ss << "[";
    for (int i = 0; i < width; ++i) {
        if (i < filled) {
            ss << "█";
        } else {
            ss << "░";
        }
    }
    ss << "] " << current << "/" << total;
    
    if (total > 0) {
        ss << " (" << std::fixed << std::setprecision(1) << (100.0 * current / total) << "%)";
    }
    
    return ss.str();
}

void Visualizer::display_header(const std::string& title) {
    std::cout << "\n";
    std::cout << "╔══════════════════════════════════════════════════════════════════════╗\n";
    std::cout << "║" << std::setw(70) << std::left << ("  " + title) << "║\n";
    std::cout << "╚══════════════════════════════════════════════════════════════════════╝\n";
}

void Visualizer::display_live_stats(const VisualizationData& data, int total_target) {
    clear_screen();
    
    display_header("API Load Tester - Live Statistics");
    
    std::cout << "\n📊 PROGRESS\n";
    std::cout << create_progress_bar(data.total_requests, total_target, 50) << "\n\n";
    
    std::cout << "📈 REQUEST STATISTICS\n";
    std::cout << create_bar_graph("✓ Successful", data.successful_requests, data.total_requests, 40) << "\n";
    std::cout << create_bar_graph("✗ Failed", data.failed_requests, data.total_requests, 40) << "\n\n";
    
    std::cout << "⚡ PERFORMANCE METRICS\n";
    std::cout << "  Total Requests:    " << data.total_requests << "\n";
    std::cout << "  Avg Response Time: " << std::fixed << std::setprecision(2) << data.avg_response_time << " ms\n";
    std::cout << "  Throughput:        " << std::fixed << std::setprecision(2) << data.throughput << " req/sec\n";
    
    if (!data.recent_response_times.empty()) {
        std::cout << create_line_graph(data.recent_response_times, "\n📉 RESPONSE TIME TREND (Last 50 requests)");
    }
    
    std::cout << "\n" << std::flush;
}

void Visualizer::display_summary(const VisualizationData& data, double min_latency, double max_latency) {
    clear_screen();
    
    display_header("API Load Test - Final Summary Report");
    
    std::cout << "\n" << std::string(70, '=') << "\n";
    std::cout << "OVERALL RESULTS\n";
    std::cout << std::string(70, '=') << "\n\n";
    
    std::cout << "Total Requests Sent:       " << data.total_requests << "\n";
    std::cout << "✓ Successful Responses:    " << data.successful_requests;
    if (data.total_requests > 0) {
        std::cout << " (" << std::fixed << std::setprecision(1) 
                  << (100.0 * data.successful_requests / data.total_requests) << "%)";
    }
    std::cout << "\n";
    
    std::cout << "✗ Failed Responses:        " << data.failed_requests;
    if (data.total_requests > 0) {
        std::cout << " (" << std::fixed << std::setprecision(1) 
                  << (100.0 * data.failed_requests / data.total_requests) << "%)";
    }
    std::cout << "\n\n";
    
    std::cout << std::string(70, '=') << "\n";
    std::cout << "LATENCY STATISTICS\n";
    std::cout << std::string(70, '=') << "\n\n";
    
    std::cout << "Average Latency:           " << std::fixed << std::setprecision(2) << data.avg_response_time << " ms\n";
    std::cout << "Minimum Latency:           " << std::fixed << std::setprecision(2) << min_latency << " ms\n";
    std::cout << "Maximum Latency:           " << std::fixed << std::setprecision(2) << max_latency << " ms\n\n";
    
    std::cout << std::string(70, '=') << "\n";
    std::cout << "THROUGHPUT\n";
    std::cout << std::string(70, '=') << "\n\n";
    
    std::cout << "Requests Per Second:       " << std::fixed << std::setprecision(2) << data.throughput << " req/sec\n\n";
    
    std::cout << std::string(70, '=') << "\n\n";
}
