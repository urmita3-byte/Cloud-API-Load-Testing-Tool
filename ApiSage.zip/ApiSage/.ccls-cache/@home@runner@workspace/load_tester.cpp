#include "load_tester.h"
#include <cpr/cpr.h>
#include <iostream>
#include <algorithm>

LoadTester::LoadTester(const RequestConfig& cfg) : config(cfg) {
    metrics.start_time = std::chrono::system_clock::now();
}

LoadTester::~LoadTester() {
    stop();
}

void LoadTester::start() {
    running = true;
    metrics.start_time = std::chrono::system_clock::now();
    
    for (int i = 0; i < config.num_threads; ++i) {
        workers.emplace_back(&LoadTester::worker_thread, this, i);
    }
}

void LoadTester::stop() {
    running = false;
    wait_for_completion();
}

void LoadTester::wait_for_completion() {
    for (auto& worker : workers) {
        if (worker.joinable()) {
            worker.join();
        }
    }
    metrics.end_time = std::chrono::system_clock::now();
}

void LoadTester::worker_thread(int worker_id) {
    for (int i = 0; i < config.requests_per_thread && running; ++i) {
        RequestResult result = send_request();
        update_metrics(result);
    }
}

RequestResult LoadTester::send_request() {
    RequestResult result;
    result.timestamp = std::chrono::system_clock::now();
    
    auto start = std::chrono::high_resolution_clock::now();
    
    try {
        cpr::Session session;
        session.SetUrl(cpr::Url{config.url});
        
        cpr::Header headers;
        for (const auto& [key, value] : config.headers) {
            headers[key] = value;
        }
        if (!headers.empty()) {
            session.SetHeader(headers);
        }
        
        cpr::Response response;
        
        if (config.method == "GET") {
            response = session.Get();
        } else if (config.method == "POST") {
            session.SetBody(cpr::Body{config.body});
            response = session.Post();
        } else if (config.method == "PUT") {
            session.SetBody(cpr::Body{config.body});
            response = session.Put();
        } else if (config.method == "DELETE") {
            response = session.Delete();
        } else {
            response = session.Get();
        }
        
        auto end = std::chrono::high_resolution_clock::now();
        result.response_time_ms = std::chrono::duration<double, std::milli>(end - start).count();
        
        result.status_code = response.status_code;
        result.success = (response.status_code >= 200 && response.status_code < 400);
        
        if (response.error.code != cpr::ErrorCode::OK) {
            result.success = false;
            result.error_message = response.error.message;
        }
        
    } catch (const std::exception& e) {
        auto end = std::chrono::high_resolution_clock::now();
        result.response_time_ms = std::chrono::duration<double, std::milli>(end - start).count();
        result.success = false;
        result.status_code = 0;
        result.error_message = e.what();
    }
    
    return result;
}

void LoadTester::update_metrics(const RequestResult& result) {
    std::lock_guard<std::mutex> lock(metrics.metrics_mutex);
    
    metrics.total_requests++;
    
    if (result.success) {
        metrics.successful_requests++;
    } else {
        metrics.failed_requests++;
    }
    
    metrics.total_response_time += result.response_time_ms;
    
    if (result.response_time_ms < metrics.min_latency) {
        metrics.min_latency = result.response_time_ms;
    }
    if (result.response_time_ms > metrics.max_latency) {
        metrics.max_latency = result.response_time_ms;
    }
    
    metrics.status_code_distribution[result.status_code]++;
    
    metrics.recent_results.push_back(result);
    if (metrics.recent_results.size() > 50) {
        metrics.recent_results.erase(metrics.recent_results.begin());
    }
}

TestMetrics LoadTester::get_metrics() const {
    return metrics;
}

double LoadTester::get_throughput() const {
    auto now = std::chrono::system_clock::now();
    auto duration = std::chrono::duration<double>(now - metrics.start_time).count();
    
    if (duration > 0) {
        return metrics.total_requests.load() / duration;
    }
    return 0.0;
}
