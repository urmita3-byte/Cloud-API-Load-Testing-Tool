#ifndef SECURITY_H
#define SECURITY_H

#include <string>
#include <vector>

struct SecurityCheckResult {
    bool is_safe;
    std::vector<std::string> warnings;
    std::vector<std::string> errors;
};

class SecurityChecker {
private:
    bool is_valid_url(const std::string& url);
    bool is_trusted_domain(const std::string& hostname);
    std::string extract_hostname(const std::string& url);
    bool check_ssl_certificate(const std::string& url);
    bool is_safe_port(int port);
    
public:
    SecurityChecker();
    
    SecurityCheckResult validate_url(const std::string& url);
    SecurityCheckResult validate_request_config(const std::string& url, const std::string& method, const std::string& body);
    bool is_suspicious_response(long status_code, double response_time_ms);
    std::string sanitize_input(const std::string& input);
    bool prompt_user_confirmation(const std::string& url);
};

#endif
