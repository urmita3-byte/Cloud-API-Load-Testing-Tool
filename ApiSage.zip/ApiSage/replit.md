# API Load Testing Tool

## Overview
A powerful C++ command-line load testing tool designed for API performance testing and security analysis. This tool provides multi-threaded load testing with real-time visualization, comprehensive metrics tracking, and integrated security checks.

## Purpose
- Perform load testing on REST API endpoints
- Track detailed performance metrics (latency, throughput, success/failure rates)
- Visualize test progress in real-time with ASCII graphs
- Detect security issues and suspicious response patterns
- Support flexible request configuration (headers, methods, body)

## Current State
The project is fully functional with the following components:
- Multi-threaded HTTP request engine using C++17 std::thread
- Real-time terminal visualization with ASCII graphs
- Security validation and suspicious pattern detection
- Support for GET, POST, PUT, DELETE methods
- Custom headers and JSON body support

## Recent Changes (November 17, 2025)
- Initial project setup with C++ development environment
- Implemented core modules: load_tester, visualizer, security
- Created comprehensive CLI interface with user prompts
- Added CMake build system configuration
- Integrated cpr library for HTTP requests
- Implemented thread-safe metrics tracking

## Project Architecture

### File Structure
```
.
├── main.cpp              # CLI interface and program entry point
├── load_tester.h/.cpp    # Multi-threaded load testing engine
├── visualizer.h/.cpp     # Real-time ASCII visualization
├── security.h/.cpp       # Security validation and checks
├── CMakeLists.txt        # Build system configuration
└── replit.md             # Project documentation
```

### Dependencies
- C++17 standard library (threading, chrono, atomic)
- cpr (C++ Requests - HTTP client library)
- nlohmann/json (JSON parsing and serialization)
- libcurl (underlying HTTP library)

### Key Features
1. **Multi-threaded Load Testing**: Concurrent request execution using std::thread
2. **Flexible Configuration**: Customizable URL, method, headers, body, thread count
3. **Real-time Visualization**: Live updating ASCII graphs and progress bars
4. **Metrics Tracking**: Response time, status codes, throughput, success/error rates
5. **Security Validation**: URL validation, SSL checking, pattern detection
6. **Detailed Reports**: Comprehensive summary with latency statistics

## User Preferences
- Clean, well-commented code
- Terminal-based interface with visual feedback
- Security-conscious design with validation checks

## Build Instructions
```bash
mkdir build && cd build
cmake ..
make
./load_tester
```

## Usage Example
1. Run the executable: `./load_tester`
2. Enter target URL (e.g., https://jsonplaceholder.typicode.com/posts)
3. Configure HTTP method, headers, and body
4. Set number of threads and requests per thread
5. Review security warnings and confirm if needed
6. Start the test and watch real-time visualization
7. Review final summary report

## Next Phase Features
- Export test results to CSV/JSON formats
- Request retry logic and timeout configuration
- Advanced port scanning for security checks
- Historical test comparison and reporting
- Configuration file support for repeatable tests
