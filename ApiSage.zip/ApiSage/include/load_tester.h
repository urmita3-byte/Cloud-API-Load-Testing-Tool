#ifndef LOAD_TESTER_H
#define LOAD_TESTER_H

#include <string>
#include <vector>
#include <map>
#include <thread>
#include <mutex>
#include <atomic>
#include <chrono>
#include <limits>

struct RequestConfig {
    std::string url;
    std::string method;
    std::map<std::string, std::string> headers;
    std::string body;
    int num_threads;
    int requests_per_thread;
};

struct RequestResult {
    long status_code;
    double response_time_ms;
    bool success;
    std::string error_message;
    std::chrono::system_clock::time_point timestamp;
};

struct TestMetrics {
    std::atomic<int> total_requests{0};
    std::atomic<int> successful_requests{0};
    std::atomic<int> failed_requests{0};
    double total_response_time = 0.0;
    double min_latency = std::numeric_limits<double>::max();
    double max_latency = 0.0;
    std::map<long, int> status_code_distribution;
    std::vector<RequestResult> recent_results;
    mutable std::mutex metrics_mutex;
    std::chrono::system_clock::time_point start_time;
    std::chrono::system_clock::time_point end_time;
};

struct MetricsSnapshot {
    int total_requests;
    int successful_requests;
    int failed_requests;
    double total_response_time;
    double min_latency;
    double max_latency;
    std::map<long, int> status_code_distribution;
    std::vector<RequestResult> recent_results;
    std::chrono::system_clock::time_point start_time;
    std::chrono::system_clock::time_point end_time;
};

class LoadTester {
private:
    RequestConfig config;
    TestMetrics metrics;
    std::vector<std::thread> workers;
    std::atomic<bool> running{false};
    
    void worker_thread(int worker_id);
    RequestResult send_request();
    void update_metrics(const RequestResult& result);

public:
    LoadTester(const RequestConfig& cfg);
    ~LoadTester();
    
    void start();
    void stop();
    void wait_for_completion();
    
    MetricsSnapshot get_metrics() const;
    double get_throughput() const;
    bool is_running() const { return running.load(); }
};

#endif
