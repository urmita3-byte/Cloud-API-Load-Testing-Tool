#include "load_tester.h"
#include "visualizer.h"
#include "security.h"
#include <iostream>
#include <thread>
#include <chrono>
#include <nlohmann/json.hpp>

using json = nlohmann::json;

void print_banner() {
    std::cout << R"(
╔══════════════════════════════════════════════════════════════════════╗
║                                                                      ║
║              🚀 API LOAD TESTING TOOL 🚀                             ║
║                                                                      ║
║     Multi-threaded API Load Testing with Real-time Visualization    ║
║                                                                      ║
╚══════════════════════════════════════════════════════════════════════╝
)" << std::endl;
}

RequestConfig get_user_input() {
    RequestConfig config;
    SecurityChecker sec_checker;
    
    std::cout << "\n📋 REQUEST CONFIGURATION\n";
    std::cout << std::string(70, '=') << "\n\n";
    
    std::cout << "Enter target URL: ";
    std::string raw_url;
    std::getline(std::cin, raw_url);
    config.url = sec_checker.sanitize_input(raw_url);
    
    std::cout << "Enter HTTP method (GET/POST/PUT/DELETE) [default: GET]: ";
    std::getline(std::cin, config.method);
    if (config.method.empty()) {
        config.method = "GET";
    }
    
    std::transform(config.method.begin(), config.method.end(), config.method.begin(), ::toupper);
    
    std::cout << "\nAdd custom headers? (yes/no) [default: no]: ";
    std::string add_headers;
    std::getline(std::cin, add_headers);
    
    if (add_headers == "yes" || add_headers == "y") {
        std::cout << "Enter headers in JSON format (e.g., {\"Content-Type\": \"application/json\"}): ";
        std::string headers_json;
        std::getline(std::cin, headers_json);
        
        try {
            json headers_obj = json::parse(headers_json);
            for (auto& [key, value] : headers_obj.items()) {
                config.headers[key] = value.get<std::string>();
            }
        } catch (const std::exception& e) {
            std::cout << "⚠️  Invalid JSON format. Continuing without custom headers.\n";
        }
    }
    
    if (config.method == "POST" || config.method == "PUT") {
        std::cout << "\nEnter request body (JSON format, or press Enter to skip): ";
        std::getline(std::cin, config.body);
    }
    
    std::cout << "\n⚙️  LOAD TESTING CONFIGURATION\n";
    std::cout << std::string(70, '=') << "\n\n";
    
    std::cout << "Number of threads [default: 5]: ";
    std::string threads_input;
    std::getline(std::cin, threads_input);
    
    if (threads_input.empty()) {
        config.num_threads = 5;
    } else {
        try {
            config.num_threads = std::stoi(threads_input);
            if (config.num_threads <= 0 || config.num_threads > 100) {
                std::cout << "⚠️  Invalid thread count. Using default: 5\n";
                config.num_threads = 5;
            }
        } catch (const std::exception&) {
            std::cout << "⚠️  Invalid input. Using default: 5\n";
            config.num_threads = 5;
        }
    }
    
    std::cout << "Requests per thread [default: 10]: ";
    std::string requests_input;
    std::getline(std::cin, requests_input);
    
    if (requests_input.empty()) {
        config.requests_per_thread = 10;
    } else {
        try {
            config.requests_per_thread = std::stoi(requests_input);
            if (config.requests_per_thread <= 0 || config.requests_per_thread > 10000) {
                std::cout << "⚠️  Invalid request count. Using default: 10\n";
                config.requests_per_thread = 10;
            }
        } catch (const std::exception&) {
            std::cout << "⚠️  Invalid input. Using default: 10\n";
            config.requests_per_thread = 10;
        }
    }
    
    return config;
}

void display_configuration(const RequestConfig& config) {
    std::cout << "\n📊 TEST CONFIGURATION SUMMARY\n";
    std::cout << std::string(70, '=') << "\n\n";
    std::cout << "URL:                " << config.url << "\n";
    std::cout << "Method:             " << config.method << "\n";
    std::cout << "Threads:            " << config.num_threads << "\n";
    std::cout << "Requests/Thread:    " << config.requests_per_thread << "\n";
    std::cout << "Total Requests:     " << (config.num_threads * config.requests_per_thread) << "\n";
    
    if (!config.headers.empty()) {
        std::cout << "\nCustom Headers:\n";
        for (const auto& [key, value] : config.headers) {
            std::cout << "  " << key << ": " << value << "\n";
        }
    }
    
    if (!config.body.empty()) {
        std::cout << "\nRequest Body:\n  " << config.body.substr(0, 100);
        if (config.body.length() > 100) {
            std::cout << "...";
        }
        std::cout << "\n";
    }
    
    std::cout << "\n" << std::string(70, '=') << "\n";
}

void run_load_test(const RequestConfig& config) {
    Visualizer visualizer;
    
    LoadTester tester(config);
    
    int total_target = config.num_threads * config.requests_per_thread;
    
    tester.start();
    
    while (tester.is_running()) {
        MetricsSnapshot metrics = tester.get_metrics();
        
        VisualizationData viz_data;
        viz_data.total_requests = metrics.total_requests;
        viz_data.successful_requests = metrics.successful_requests;
        viz_data.failed_requests = metrics.failed_requests;
        
        if (metrics.total_requests > 0) {
            viz_data.avg_response_time = metrics.total_response_time / metrics.total_requests;
        } else {
            viz_data.avg_response_time = 0.0;
        }
        
        viz_data.throughput = tester.get_throughput();
        
        for (const auto& result : metrics.recent_results) {
            viz_data.recent_response_times.push_back(result.response_time_ms);
        }
        
        visualizer.display_live_stats(viz_data, total_target);
        
        if (metrics.total_requests >= total_target) {
            break;
        }
        
        std::this_thread::sleep_for(std::chrono::milliseconds(500));
    }
    
    tester.wait_for_completion();
    
    MetricsSnapshot final_metrics = tester.get_metrics();
    
    VisualizationData final_viz_data;
    final_viz_data.total_requests = final_metrics.total_requests;
    final_viz_data.successful_requests = final_metrics.successful_requests;
    final_viz_data.failed_requests = final_metrics.failed_requests;
    
    if (final_metrics.total_requests > 0) {
        final_viz_data.avg_response_time = final_metrics.total_response_time / final_metrics.total_requests;
    } else {
        final_viz_data.avg_response_time = 0.0;
    }
    
    final_viz_data.throughput = tester.get_throughput();
    
    visualizer.display_summary(final_viz_data, final_metrics.min_latency, final_metrics.max_latency);
    
    SecurityChecker security_checker;
    std::cout << "\n🔒 SECURITY ANALYSIS\n";
    std::cout << std::string(70, '=') << "\n\n";
    
    bool has_warnings = false;
    
    for (const auto& result : final_metrics.recent_results) {
        if (security_checker.is_suspicious_response(result.status_code, result.response_time_ms)) {
            has_warnings = true;
            if (result.status_code == 429) {
                std::cout << "⚠️  Rate limiting detected (HTTP 429)\n";
                break;
            } else if (result.status_code >= 500) {
                std::cout << "⚠️  Server errors detected (HTTP " << result.status_code << ")\n";
                break;
            } else if (result.response_time_ms > 10000) {
                std::cout << "⚠️  Abnormally long response times detected (>" << result.response_time_ms << "ms)\n";
                break;
            }
        }
    }
    
    if (!has_warnings) {
        std::cout << "✅ No suspicious patterns detected\n";
    }
    
    std::cout << "\n" << std::string(70, '=') << "\n";
    std::cout << "\n✨ Load test completed successfully!\n\n";
}

int main() {
    print_banner();
    
    RequestConfig config = get_user_input();
    
    SecurityChecker security_checker;
    SecurityCheckResult security_result = security_checker.validate_request_config(
        config.url, config.method, config.body
    );
    
    if (!security_result.is_safe) {
        std::cout << "\n🚨 SECURITY ERRORS DETECTED:\n";
        for (const auto& error : security_result.errors) {
            std::cout << "  ❌ " << error << "\n";
        }
        std::cout << "\nCannot proceed with the test.\n";
        return 1;
    }
    
    if (!security_result.warnings.empty()) {
        std::cout << "\n⚠️  SECURITY WARNINGS:\n";
        for (const auto& warning : security_result.warnings) {
            std::cout << "  ⚠️  " << warning << "\n";
        }
        
        if (!security_checker.prompt_user_confirmation(config.url)) {
            std::cout << "\n❌ Test cancelled by user.\n";
            return 0;
        }
    }
    
    display_configuration(config);
    
    std::cout << "\nPress Enter to start the load test...";
    std::cin.get();
    
    try {
        run_load_test(config);
    } catch (const std::exception& e) {
        std::cerr << "\n❌ Error during load test: " << e.what() << "\n";
        return 1;
    }
    
    return 0;
}
